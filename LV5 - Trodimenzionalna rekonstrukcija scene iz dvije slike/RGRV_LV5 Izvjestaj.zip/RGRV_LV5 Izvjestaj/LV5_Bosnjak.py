import cv2
import numpy as np
import json
import convert_2d_points_to_3d_points as convert
import plot_3d_points

def main():
    #Učitavanje slika
    imageL=cv2.imread("./LV/LV5/imageL.jpg")
    imageR=cv2.imread("./LV/LV5/imageR.jpg")
    cv2.imshow("Left image", imageL)
    cv2.imshow("Right image", imageR)
    cv2.waitKey()
    cv2.destroyAllWindows()

    #Pronalaženje keypointova i deskriptora SIFT metodom
    sift = cv2.SIFT_create()
    keypointsL, descriptorsL=sift.detectAndCompute(imageL, None)
    keypointsR, descriptorsR=sift.detectAndCompute(imageR, None)
    keypoints_imageL=cv2.drawKeypoints(imageL,keypointsL,cv2.DRAW_MATCHES_FLAGS_DEFAULT)
    keypoints_imageR=cv2.drawKeypoints(imageR,keypointsR,cv2.DRAW_MATCHES_FLAGS_DEFAULT)
    cv2.imshow("Keypoints of left image", keypoints_imageL)
    cv2.imshow("Keypoints of right image", keypoints_imageR)
    cv2.waitKey()
    cv2.destroyAllWindows()

    #FLANN metoda za sparivanje keypointova
    FLANN_INDEX_KDTREE = 1
    index_params = dict(algorithm = FLANN_INDEX_KDTREE, trees = 5)
    search_params = dict(checks=50)
    
    flann = cv2.FlannBasedMatcher(index_params,search_params)
    matches = flann.knnMatch(descriptorsL,descriptorsR,k=2)

    #Ratio test za "dobre" keypointove
    threshhold=0.67
    good = []
    points1 = []
    points2 = []
    for m,n in matches:
        if m.distance < threshhold*n.distance:
            good.append(m)
            points2.append(keypointsR[m.trainIdx].pt)
            points1.append(keypointsL[m.queryIdx].pt)
    
    matches_image = cv2.drawMatches(imageL,keypointsL,imageR,keypointsR,good,None,flags=cv2.DrawMatchesFlags_NOT_DRAW_SINGLE_POINTS)

    cv2.imshow("Matches",matches_image)
    cv2.waitKey()
    cv2.destroyAllWindows()

    points1 = np.int32(points1)
    points2 = np.int32(points2)

    #Fundamentalna matrica i maska
    F, mask = cv2.findFundamentalMat(points1,points2,cv2.FM_RANSAC)

    #Pomoću maske se rješavaju outlieri
    points1 = points1[mask.ravel()==1]
    points2 = points2[mask.ravel()==1]

    matchesMask = mask.ravel().tolist()

    matches_image = cv2.drawMatches(imageL,keypointsL,imageR,keypointsR,good,None,flags=2,matchesMask=matchesMask)

    cv2.imshow("Matches",matches_image)
    cv2.waitKey()
    cv2.destroyAllWindows()

    #Učitavanje projekcijske matrice
    f=open("./LV/LV5/camera_params.json")
    dictionary=json.load(f)

    P=np.array(dictionary["camera_params"])

    #Formula za esencijalnu matricu
    E=P.T@F@P

    points1 = np.float64(points1)
    points2 = np.float64(points2)

    k_points_L=[]
    k_points_R=[]

    #Svaki od dobrih parova staviti u novu listu oblika cv2.KeyPoint
    for i in range(points1.shape[0]):
        if mask[i] == 1:
            k_points_L.append(cv2.KeyPoint(points1[i][0], points1[i][1], 1))
            k_points_R.append(cv2.KeyPoint(points2[i][0], points2[i][1], 1))

    #Funckija za konvertiranje 2d točaka u 3d točke
    points_3d=convert.convert_2d_points_to_3d_points(k_points_L,k_points_R,E,P)

    #Spremanje u json datoteku
    points_3d=json.dumps(points_3d.tolist())
    with open("./LV/LV5/points_3d.json","w") as of:
        of.write(points_3d)

    #Crtanje 3d točaka pozivom funkcije plot_3d_points
    plot_3d_points.main()


if __name__=='__main__':
    main()