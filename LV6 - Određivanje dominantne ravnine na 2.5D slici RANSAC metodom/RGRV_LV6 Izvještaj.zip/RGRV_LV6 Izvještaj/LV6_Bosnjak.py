import numpy as np
import read_kinect_pic
import cv2
import random
import copy
from multiprocessing import Pool
from tqdm import tqdm

def ransac(imageFilePath):
    depthFilePath=imageFilePath[:-4] #s obzirom da su filepath-ovi isti kao i za slike, samo je razlika u zadnjih par znakova ->
    depthFilePath=depthFilePath + "-D.txt" #oduzme se zadnjih 4 znaka putanje do slike što predstavlja ".txt" i doda se string "-D.txt"
    image = cv2.imread(imageFilePath)
    height, width, channels = image.shape
    depth_image, point_3d_array, n_3d_points = read_kinect_pic.read_kinect_pic(depthFilePath, (height, width))
    n_iter=300 #broj iteracija ransac algoritma
    T=[]
    T_=[]
    R_=[]
    dominant_plane=copy.deepcopy(depth_image) #kopiranje depth_image za spremanje slike sa dominantnom ravninom
    dominant_plane=cv2.cvtColor(dominant_plane,cv2.COLOR_GRAY2RGB) #prebacivanje depth_image u rgb sliku zbog potrebe za mijenjanjem boja na slici
    for i in range(n_iter):
        while 1:
            try:
                randomPoints=random.choices(point_3d_array, k=3) #nasumično odaberi 3 točke
                A=[ [randomPoints[0][0], randomPoints[0][1], 1],
                    [randomPoints[1][0], randomPoints[1][1], 1],
                    [randomPoints[2][0], randomPoints[2][1], 1] ] 
                C=[ [randomPoints[0][2]],
                    [randomPoints[1][2]],
                    [randomPoints[2][2]]]
                A=np.asarray(A)
                C=np.asarray(C)
                R=np.linalg.inv(A)@C #jednadžba (2), funkcija np.linalg.inv daje exception ako nije u mogućnosti napraviti inverznu matricu
                break #pronađena dobra ravnina 
            except:
                continue #pokušaj opet
        threshold=4 #threshold odstupanja točke od ravnine zbog mjernog šuma (u mm)
        for point in point_3d_array:
            if(abs(point[2] - (R[0] * point[0] + R[1] * point[1] + R[2])) <= threshold): #ako je unutar zadanog thresholda ->
                T.append(point) #dodaj u popis točaka koje pripadaju ravnini
        if(len(T)>len(T_)):
            T_=T
            R_=R
        T=[] #isprazni listu točaka
    for point in T_:
        dominant_plane[point[1],point[0]]=np.array((0,255,0))

    return image, depth_image, dominant_plane

def main():
    imagesFilePath=[
                    "./LV/LV6/sl-00001.bmp",
                    "./LV/LV6/sl-00002.bmp",
                    "./LV/LV6/sl-00003.bmp",
                    "./LV/LV6/sl-00133.bmp",
                    "./LV/LV6/sl-00242.bmp",
                    "./LV/LV6/sl-00270.bmp",
                    "./LV/LV6/sl-00300.bmp",
                    "./LV/LV6/sl-00392.bmp",
                    "./LV/LV6/sl-00411.bmp"] #lista argumenata za funkciju ransac
    with Pool(9) as p:
        res = list(tqdm(p.imap(ransac, imagesFilePath), total=len(imagesFilePath))) #pozivanje funkcije ransac 9 puta odjednom sa svim argumentima 
    for images in res: #prikaz redom svih slika i dominantnih ravnina na tim slikama
        cv2.imshow("Image", images[0])
        cv2.imshow("Depth image", images[1])
        cv2.waitKey()
        cv2.destroyAllWindows()
        cv2.imshow("Image", images[0])
        cv2.imshow("Colored image", images[2])
        cv2.waitKey()
        cv2.destroyAllWindows()


if __name__=='__main__':
    main()




