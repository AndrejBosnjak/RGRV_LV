import sys
import numpy as np
import read_kinect_pic
import cv2
import random
import copy
from multiprocessing import Pool
from tqdm import tqdm

imageFilePath="./LV/LV6/sl-00133.bmp"

def ransac(point_3d_array):
    n_iter=100
    T=[]
    T_=[]
    R_=[]
    for i in range(n_iter):
        while 1:
            try:
                randomPoints=random.choices(point_3d_array, k=3)
                A=[ [randomPoints[0][0], randomPoints[0][1], 1],
                    [randomPoints[1][0], randomPoints[1][1], 1],
                    [randomPoints[2][0], randomPoints[2][1], 1] ] 
                C=[ [randomPoints[0][2]],
                    [randomPoints[1][2]],
                    [randomPoints[2][2]]]
                A=np.asarray(A)
                C=np.asarray(C)
                R=np.linalg.inv(A)@C
                break
            except:
                continue
        threshold=4
        for point in point_3d_array:
            if(abs(point[2] - (R[0] * point[0] + R[1] * point[1] + R[2])) <= threshold):
                T.append(point)
        if(len(T)>len(T_)):
            T_=T
            R_=R
        T=[]
    return T_, R_
 

def main():
    image=cv2.imread(imageFilePath)
    depthFilePath=imageFilePath[:-4]
    depthFilePath=depthFilePath + "-D.txt" 
    height, width, channels = image.shape
    depth_image, point_3d_array, n_3d_points = read_kinect_pic.read_kinect_pic(depthFilePath, (height, width))
    dominant_plane=copy.deepcopy(depth_image)
    dominant_plane=cv2.cvtColor(dominant_plane,cv2.COLOR_GRAY2RGB)
    points_3d_array=[]
    for i in range(10):
        points_3d_array.append(point_3d_array) #lista argumenata za multiprocesiranje
    r=0
    g=255
    b=0 #prva boja će biti zelena za najdominantniju ravninu
    while (len(point_3d_array)>1000): #sve dok se ne označe sve ravnine na slici koje sadrže više od 1000 točaka
        with Pool(10) as p:
            res = list(tqdm(p.imap(ransac, points_3d_array), total=len(points_3d_array))) #pozovi funckiju ransac 10 puta sa istim skupom point_3d_array
        T_=[]
        for result in res:
            if len(result[0])>len(T_):
                T_=result[0] #pronađi najveći skup točaka iz skupa rezultata
        for point in T_:
            dominant_plane[point[1],point[0]]=np.array((r,g,b))
            point_3d_array.remove(point) #odbaci već obojanu ravninu
        points_3d_array=[]
        for i in range(10):
            points_3d_array.append(point_3d_array) #ponovno ispuni listu argumenata sa izbačenom ravninom
        r=random.randint(0,255)
        g=random.randint(0,255)
        b=random.randint(0,255) #random boja za iduću ravninu
    cv2.imshow("Image", image)
    cv2.imshow("Depth image", depth_image)
    cv2.waitKey()
    cv2.destroyAllWindows()
    cv2.imshow("Image", image)
    cv2.imshow("All planes", dominant_plane)
    cv2.waitKey()
    cv2.destroyAllWindows()


if __name__=='__main__':
    main()

